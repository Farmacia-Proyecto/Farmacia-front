<template>
    <nav class="nav-bar">
      <ul class="nav-menu">
        <li class="nav-item"><a href="#home">Inicio</a></li>
        <li class="nav-item"><a href="#about">Acerca de</a></li>
        <li class="nav-item"><a href="#services">Servicios</a></li>
        <li class="nav-item"><a href="#contact">Contacto</a></li>
      </ul>
      <div class="nav-title">Administrador</div>
      <div class="name-user">Sebastian Daza</div>
      <div class="user-icon" @click="toggleDropdown">
        <font-awesome-icon icon="fa-solid fa-user" class="icon" />
        <!-- Menú desplegable -->
        <div v-if="showDropdown" class="dropdown-menu">
          <a href="#change-password" class="dropdown-item">Cambiar Contraseña</a>
          <a class="dropdown-item" @click="logout">Cerrar Sesión</a>
        </div>
      </div>
    </nav>
  </template>
  
  <script>
  export default {
    data() {
      return {
        showDropdown: false, 
      };
    },
    methods: {
      toggleDropdown() {
        this.showDropdown = !this.showDropdown; 
      },
      logout(){
        this.$router.push("/")
      }
    },
  };
  </script>
  
  <style scoped>
  .nav-bar {
    background-color: #1ab188;
    border-radius: 7px;
    padding: 1rem;
    display: flex;
    align-items: center;
    position: relative;
  }
  
  .nav-menu {
    display: flex;
    list-style: none;
    margin: 0;
    padding: 0;
  }
  
  .nav-item {
    margin-right: 1.5rem;
  }
  
  .nav-item a {
    color: black;
    text-decoration: none;
    padding: 0.5rem 1rem;
    transition: background 0.3s;
  }
  
  .nav-item a:hover {
    background-color: #0b9185;
    border-radius: 5px;
  }
  
  .nav-title {
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
    color: black;
    font-size: 1.2rem;
    font-weight: bold;
  }
  
  .name-user {
    margin-left: auto;
    margin-right: 1rem;
    color: black;
    font-size: 1.2rem;
    font-weight: bold;
  }
  
  .user-icon {
    position: relative;
    cursor: pointer;
    font-size: 1.5rem;
    color: black;
  }
  
  .icon:hover {
    color: #0b9185;
  }
  
  .dropdown-menu {
    position: absolute;
    top: 100%;
    right: 0;
    background-color: white;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    border-radius: 5px;
    padding: 0.5rem;
    z-index: 10;
  }
  
  .dropdown-item {
    display: block;
    padding: 0.5rem 1rem;
    color: black;
    text-decoration: none;
    transition: background 0.3s;
    font-size: medium;
  }
  
  .dropdown-item:hover {
    background-color: #0b9185;
    color: white;
    border-radius: 3px;
  }
  </style>
  