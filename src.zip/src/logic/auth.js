import axios from "axios";

export default {
  async login(login, password) {
    const response = await axios.post(
      "http://192.168.20.77:3000/api/login",
      { login, password },
      { withCredentials: true }
    );
    const token = response.data.token;
    sessionStorage.setItem("jwt", token);
  }
};
